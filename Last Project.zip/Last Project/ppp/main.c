// C program to Open a File,
// Read from it, And Close the File

# include <stdio.h>
# include <string.h>

int main( )
{
    FILE *filePointer1 ;
    char dataToBeWritten[1000] = "{\"username\":\"ali\",\"bio\":\"hi iam ali.\",\"numberOfFollowers\":1,\"numberOfFollowings\":0,\"followStatus\":\"NotFollowed\"}";
    filePointer1 = fopen("aa.txt", "w");
    if ( filePointer1 == NULL ){
        printf( "GfgTest.c file failed to open." ) ;
    }
    else{
        if (strlen (  dataToBeWritten  ) > 0){
            fputs(dataToBeWritten, filePointer1) ;
            fputs("\n", filePointer1) ;
        }
        fclose(filePointer1) ;
    }



	FILE *filePointer ;
	char dataToBeRead[1000];
	char new1[1000]={};
	char new2[1000] = {};
	filePointer = fopen("aa.txt", "r") ;
	if ( filePointer == NULL ){
		printf( "GfgTest.c file failed to open." ) ;
	}
	else{
		while( fgets ( dataToBeRead, 50, filePointer ) != NULL ){
			sprintf(new1, "%s", dataToBeRead);
			strcat(new2, new1);
		}
		fclose(filePointer) ;
	}
	//printf("%s", new2);
	return 0;
}
