#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#define ASCII_START 32
#define ASCII_END 126
#include <dirent.h>

int main()
{
    ///Good signup
    char correct_singup[1000] = "{\"type\":\"Successful\",\"message\":\"\"}";
    //printf("%s\n", correct_signup);

    ///Bad singup
    char incorrect_signup[1000] = "{\"type\":\"Error\",\"message\":\"This username is already taken.\"}";
    //printf("%s\n", incorrect_singup);

    ///Incorrect Password
    char incorrect_password[1000] = "{\"type\":\"Error\",\"message\":\"Incorrect Password.\"}";
    //printf("%s", incorrect_password);

    ///Incorrect username in signin
    char invalid_username[1000] = "{\"type\":\"Error\",\"message\":\"This username is not valid.\"}";
    //printf("%s", invalid_username);

    ///already logged in
    char already_logged[1000] = "{\"type\":\"Error\",\"message\":\"This username is already logged in.\"}";
    //printf("%s", already_logged);

    ///good signin
    char good_signin[1000] = "{\"type\":\"Token\",\"message\":\"gsnjksgsjksssf\"}";
    //printf("%s", good_signin);

    ///send tweet
    char send_tweet[1000] = "{\"type\":\"Successful\",\"message\":\"Tweet is sent successfully.\"}";
    //printf("%s\n", send_tweet);

    ///Invalid_search
    char invalid_search[1000] = "{\"type\":\"Error\",\"message\":\"This username is not valid.\"}";
    //printf("%s", invalid_search);


    ///tweet profile
    char tweet_profile[1000]="{\"username\":\"ali\",\"bio\":\"hi iam ali.\",\"numberOfFollowers\":1,\"numberOfFollowings\":0,\"followStatus\":\"NotFollowed\"}";
    //printf("{\"type\":\"Profile\",\"message\":%s}", tweet_profile);

    ///good setbio
    char good_setbio[1000] = "{\"type\":\"Successful\",\"message\":\"Bio is updated successfully\"}";
    //printf("%s\n", good_setbio);

    ///good pass
    char good_pass[1000] = "{\"type\":\"Successful\",\"message\":\"Password is changed successfully.\"}";
    //printf("%s\n", good_pass);

    ///bad pass - wrong
    char bad_pass_wrong[1000] = "{\"type\":\"Error\",\"message\":\"Entered current password is wrong.\"}";
    //printf("%s\n", bad_pass_wrong);

    ///bad pass - equal
    char bad_pass_equal[1000] = "{\"type\":\"Error\",\"message\":\"New password is equal to current password.\"}";
    //printf("%s\n", bad_pass_equal);

    ///refrsh
    char refresh[1000];
    //printf("{\"type\":\"List\",\"message\":\[%s]}", refresh);

    ///Logout
    char logout[1000] = "{\"type\":\"Successful\",\"message\":\"\"}";
    //printf("%s\n", logout);

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //char *feed = (char*) calloc(100, sizeof(char));
    //char b11[100][100]={};
   // gets(feed);
   //char *pch12 = (char*) calloc(100, sizeof(char));
   // pch12 = strtok(feed, "\",: ");
    //int i = 0;
    //int login_flag
    //while (pch12 != NULL){
      //  if(strncmp("login", pch12) == 0){

      //  }
       // printf("%s\n", pch12);
       // pch12 = strtok(NULL, "\",: ");
       // i++;
   // }
    srand(time(NULL));
    char string11[25]={};
    for( int i = 0; i < 25; ++i){
        string11[i] = '0' + rand()%72; // starting on '0', ending on '}'
    }
    //printf("{\"type\":\"Token\",\"message\":\"%s\"}", string11);
    //char aa[1000];
    //gets(aa);
    char *token;
            //token = strtok(aa, "\" ,:");
            //while( token != NULL ) {
                //printf("%s\n", token);
                //token = strtok(NULL, "\" ,:");
            //}


    DIR *d;
    struct dirent *dir;
    d = opendir(".");
    if (d)
    {
        while ((dir = readdir(d)) != NULL)
        {
            printf("%s\n", dir->d_name);
        }
        closedir(d);
    }

    return 0;
}
