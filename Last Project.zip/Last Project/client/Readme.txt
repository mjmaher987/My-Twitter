# Twitter_Server
"Resources" directory is includes "Users" and "Tweets" directory should be side of the server.jar file.