#include <stdio.h>
#include <stdlib.h>

int main()
{
    char* f = "followers";
    char* h = (char*) calloc(100, sizeof(char));
    gets(h);
    printf("%s\n", strstr(h,f));
    return 0;
}
